<?php

//$conn=mysqli_connect("localhost","root","");
define('HOST','localhost');
define('USER','awdoaxbf_openpost');
define('PASS','ranojan@123');
define('DB','awdoaxbf_iotdb');    
$conn = mysqli_connect(HOST,USER,PASS,DB)or die('try again in some minutes, please');    
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
//echo "Connected successfully mysql";
}
 
     $id=trim($_POST['id']);
	 $title=trim($_POST['title']);
	 $question=trim($_POST['question']);
	 $option_1=trim($_POST['option_1']);
	 $option_2=trim($_POST['option_2']);
	 $option_3=trim($_POST['option_3']);
	 $option_4=trim($_POST['option_4']);
	 $correct_answer=trim($_POST['correct_answer']);
	 
	 //$qry1="select * from register where email='$email' "; 
	 //$raw=mysqli_query($conn,$qry1);
	// $count=mysqli_num_rows($raw);
	 
	// if($count>0)
	// {
	//	 $response="exist";
	// }
	 //else{
		 
		 $qry2="INSERT INTO `quiz` (`id`, `title`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `correct_answer`) VALUES (NULL, '$title', '$question', '$option_1', '$option_2', '$option_3', '$option_4', '$correct_answer')";
		 $res=mysqli_query($conn,$qry2);
		 
		 if($res==true)
			 //$response="inserted";	
             $response['message']="inserted";		 
		 else
			 //$response="failed";
		     $response['message']="failed";
		 
	// }
	 
	 
	// echo $response;
	echo json_encode($response);



/*
include 'db/db_connect.php';
$device_id = "";
$zone_id = $_POST['zone_id'];
if(isset($_POST['userUniqueId'])){
 $userUniqueId = $_POST['userUniqueId'];
if(isset($_POST['zone_id'])){
$sql = "SELECT * FROM train_info WHERE zone_id='$zone_id'";
}else{
$sql = "SELECT * FROM train_info WHERE 1";
}
$res = mysqli_query($con,$sql);

$temparray = array();
while($row = mysqli_fetch_row($res)){
         $data = array("status"=>"true","id"=>$row[0],"device_id"=>$row[1],"device_name"=>$row[2],"device_room_name"=>$row[4],"zone_id"=>$row[3]); 

$arr=  array_push($temparray, $data);
}   
$arr= array("status"=>"true","message"=>"Data fetched successfully!", "data" => $temparray);
}
echo json_encode($arr, JSON_UNESCAPED_UNICODE);
//echo  json_encode($data, JSON_UNESCAPED_UNICODE); 
//echo '"'.addslashes(json_encode($data, JSON_UNESCAPED_UNICODE)).'"'; 
//echo  addslashes(json_encode($data, JSON_UNESCAPED_UNICODE));    
mysqli_close($con);    
?>

*/


?>