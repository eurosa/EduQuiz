<?php

// $conn=mysqli_connect("localhost","root","");
 
define('HOST','localhost');
define('USER','awdoaxbf_openpost');
define('PASS','ranojan@123');
define('DB','awdoaxbf_iotdb');    
$conn = mysqli_connect(HOST,USER,PASS,DB)or die('try again in some minutes, please');   
 
// mysqli_select_db($conn,"eduorigin");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
//echo "Connected successfully mysql";
}
 
     $name=trim($_POST['name']);
	 $email=trim($_POST['email']);
	 $password=trim($_POST['password']);
	 
	 $qry1="select * from register where email='$email' "; 
	 $raw=mysqli_query($conn,$qry1);
	 $count=mysqli_num_rows($raw);
	 
	 if($count>0)
	 {
		 $response="exist";
	 }
	 else{
		 
		 $qry2="INSERT INTO `register` (`id`, `name`, `email`, `password`) VALUES (NULL, '$name', '$email', '$password')";
		 $res=mysqli_query($conn,$qry2);
		 
		 if($res==true)
			 //$response="inserted";	
             $response['message']="inserted";		 
		 else
			 //$response="failed";
		     $response['message']="failed";
		 
	 }
	 
	 
	// echo $response;
	echo json_encode($response);




?>