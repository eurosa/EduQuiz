<?php

define('HOST','localhost');
define('USER','awdoaxbf_openpost');
define('PASS','ranojan@123');
define('DB','awdoaxbf_iotdb');    
$conn = mysqli_connect(HOST,USER,PASS,DB)or die('try again in some minutes, please');   
 
// mysqli_select_db($conn,"eduorigin");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
//echo "Connected successfully mysql";
}
 
      $name=trim($_POST['name']);
	  $description=trim($_POST['description']);
	  $image=trim($_POST['image']);
	  $pdf=trim($_POST['pdf']);
	  
	  $filename="IMG".rand().".jpg";
	  $pdffilename="PD".rand().".pdf";
	  file_put_contents("images/".$filename,base64_decode($image));
	  file_put_contents("pdfs/".$pdffilename,base64_decode($pdf));
	  
	               $qry="INSERT INTO `book_library_backup` (`id`, `name`, `description`, `image`, `pdf`) VALUES (NULL, '$name', '$description', '$filename', '$pdffilename')";
				   $res=mysqli_query($conn,$qry);
				   
				   if($res==true)
					   echo "File Uploaded";
				   
				   else
					   echo "File Could Not Uploaded";



?>