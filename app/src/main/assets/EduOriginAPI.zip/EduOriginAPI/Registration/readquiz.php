<?php

//$conn=mysqli_connect("localhost","root","");
define('HOST','localhost');
define('USER','awdoaxbf_openpost');
define('PASS','ranojan@123');
define('DB','awdoaxbf_iotdb');    
$conn = mysqli_connect(HOST,USER,PASS,DB)or die('try again in some minutes, please');    
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
//echo "Connected successfully mysql";
}
 
 
 $qry="select * from quiz";
 
 $raw=mysqli_query($conn,$qry);
 
 while($res=mysqli_fetch_array($raw))
 {
	 $data[]=$res;
 }
 
 print(json_encode($data));


?>