<?php


//$conn=mysqli_connect("localhost","root","");
define('HOST','localhost');
define('USER','awdoaxbf_openpost');
define('PASS','ranojan@123');
define('DB','awdoaxbf_iotdb');    
$conn = mysqli_connect(HOST,USER,PASS,DB)or die('try again in some minutes, please');    
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else{
//echo "Connected successfully mysql";
}

// mysqli_select_db($conn,"eduorigin");

    $email=trim($_POST['email']);
	$password=trim($_POST['password']);
	
	$qry="select * from register where email='$email' and password='$password'";
	$raw=mysqli_query($conn,$qry);
	$count=mysqli_num_rows($raw);
	
	if($count>0)
	   $response['message']="exist";
       //$response="exist";
   
    else
		$response['message']="failed";
	      //$response="failed";
	
	
	echo json_encode($response); //Output: message=>exist message =>failed
	//echo $response;


?>